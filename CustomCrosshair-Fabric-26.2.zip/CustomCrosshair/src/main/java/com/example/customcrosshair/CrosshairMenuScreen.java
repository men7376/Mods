package com.example.customcrosshair;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.AbstractSliderButton;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.function.IntConsumer;

public class CrosshairMenuScreen extends Screen {
    private static final String[] STYLES = {"Cruz", "Ponto", "Círculo", "T"};
    private static final String[] MODES = {"Nenhum", "Mudar cor", "Cantos", "Cor + Cantos"};
    private static final int COL_W = 130, STEP = 22, X1 = 15, X2 = X1 + COL_W + 5;

    private final CrosshairConfig cfg = CrosshairConfig.get();
    private int page = 0;                 // 0 = Mira, 1 = Alvo
    private boolean simulateTarget = false;

    public CrosshairMenuScreen() { super(Component.literal("Mira Personalizada")); }

    @Override
    protected void init() {
        Button tab0 = Button.builder(Component.literal("Mira"), b -> { page = 0; simulateTarget = false; rebuildWidgets(); })
                .bounds(X1, 28, COL_W, 20).build();
        Button tab1 = Button.builder(Component.literal("Alvo (entidade)"), b -> { page = 1; simulateTarget = true; rebuildWidgets(); })
                .bounds(X2, 28, COL_W, 20).build();
        tab0.active = page != 0;
        tab1.active = page != 1;
        addRenderableWidget(tab0);
        addRenderableWidget(tab1);

        int y = 54;
        if (page == 0) {
            addRenderableWidget(Button.builder(toggle("Ativada", cfg.enabled), b -> {
                cfg.enabled = !cfg.enabled; b.setMessage(toggle("Ativada", cfg.enabled));
            }).bounds(X1, y, COL_W, 20).build());

            addRenderableWidget(Button.builder(Component.literal("Estilo: " + STYLES[cfg.style]), b -> {
                cfg.style = (cfg.style + 1) % STYLES.length; cfg.dirty = true;
                b.setMessage(Component.literal("Estilo: " + STYLES[cfg.style]));
            }).bounds(X1, y + STEP, COL_W, 20).build());

            addRenderableWidget(Button.builder(toggle("Contorno", cfg.outline), b -> {
                cfg.outline = !cfg.outline; b.setMessage(toggle("Contorno", cfg.outline));
            }).bounds(X1, y + STEP * 2, COL_W, 20).build());

            addRenderableWidget(slider(X1, y + STEP * 3, "Tamanho", 1, 30, cfg.size, v -> cfg.size = v));
            addRenderableWidget(slider(X1, y + STEP * 4, "Espessura", 1, 8, cfg.thickness, v -> cfg.thickness = v));
            addRenderableWidget(slider(X1, y + STEP * 5, "Espaço", 0, 15, cfg.gap, v -> cfg.gap = v));

            addRenderableWidget(slider(X2, y, "Ponto central", 0, 6, cfg.dotSize, v -> cfg.dotSize = v));
            addRenderableWidget(slider(X2, y + STEP, "Vermelho", 0, 255, cfg.red, v -> cfg.red = v));
            addRenderableWidget(slider(X2, y + STEP * 2, "Verde", 0, 255, cfg.green, v -> cfg.green = v));
            addRenderableWidget(slider(X2, y + STEP * 3, "Azul", 0, 255, cfg.blue, v -> cfg.blue = v));
            addRenderableWidget(slider(X2, y + STEP * 4, "Opacidade", 20, 255, cfg.alpha, v -> cfg.alpha = v));
            addRenderableWidget(Button.builder(Component.literal("Resetar tudo"), b -> { cfg.reset(); rebuildWidgets(); })
                    .bounds(X2, y + STEP * 5, COL_W, 20).build());
        } else {
            addRenderableWidget(Button.builder(Component.literal("Ao mirar: " + MODES[cfg.targetMode]), b -> {
                cfg.targetMode = (cfg.targetMode + 1) % MODES.length; cfg.dirty = true;
                b.setMessage(Component.literal("Ao mirar: " + MODES[cfg.targetMode]));
            }).bounds(X1, y, COL_W * 2 + 5, 20).build());

            addRenderableWidget(Button.builder(toggle("Simular alvo", simulateTarget), b -> {
                simulateTarget = !simulateTarget; b.setMessage(toggle("Simular alvo", simulateTarget));
            }).bounds(X1, y + STEP, COL_W * 2 + 5, 20).build());

            addRenderableWidget(slider(X1, y + STEP * 2, "Cor alvo: Verm.", 0, 255, cfg.targetRed, v -> cfg.targetRed = v));
            addRenderableWidget(slider(X1, y + STEP * 3, "Cor alvo: Verde", 0, 255, cfg.targetGreen, v -> cfg.targetGreen = v));
            addRenderableWidget(slider(X1, y + STEP * 4, "Cor alvo: Azul", 0, 255, cfg.targetBlue, v -> cfg.targetBlue = v));

            addRenderableWidget(slider(X2, y + STEP * 2, "Canto: tamanho", 1, 15, cfg.cornerSize, v -> cfg.cornerSize = v));
            addRenderableWidget(slider(X2, y + STEP * 3, "Canto: distância", 3, 30, cfg.cornerDist, v -> cfg.cornerDist = v));
        }

        addRenderableWidget(Button.builder(Component.literal("Concluído"), b -> onClose())
                .bounds(X1, height - 28, COL_W * 2 + 5, 20).build());
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
        super.extractRenderState(g, mouseX, mouseY, delta);
        centered(g, "Mira Personalizada", (X1 + X2 + COL_W) / 2, 12, 0xFFFFFFFF);

        int px = (X2 + COL_W + width) / 2, py = height / 2;
        centered(g, "Pré-visualização", px, py - 62, 0xFFAAAAAA);
        g.fill(px - 48, py - 48, px + 48, py + 48, 0xFF3A3A3A);
        CrosshairRenderer.draw(g, px, py, simulateTarget);
    }

    private void centered(GuiGraphicsExtractor g, String text, int cx, int y, int color) {
        g.text(font, text, cx - font.width(text) / 2, y, color, true);
    }

    @Override
    public void removed() { CrosshairConfig.save(); } // salva so ao fechar

    private IntSlider slider(int x, int y, String label, int min, int max, int value, IntConsumer set) {
        return new IntSlider(x, y, COL_W, label, min, max, value, v -> { set.accept(v); cfg.dirty = true; });
    }

    private static Component toggle(String name, boolean on) {
        return Component.literal(name + ": " + (on ? "Sim" : "Não"));
    }

    private static class IntSlider extends AbstractSliderButton {
        private final String label; private final int min, max; private final IntConsumer onChange;

        IntSlider(int x, int y, int w, String label, int min, int max, int value, IntConsumer onChange) {
            super(x, y, w, 20, Component.empty(), (value - min) / (double) (max - min));
            this.label = label; this.min = min; this.max = max; this.onChange = onChange;
            updateMessage();
        }

        private int current() { return min + (int) Math.round(value * (max - min)); }

        @Override protected void updateMessage() { setMessage(Component.literal(label + ": " + current())); }
        @Override protected void applyValue() { onChange.accept(current()); }
    }
}
