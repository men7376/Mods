package com.example.customcrosshair;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElement;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.KeyMapping;
import net.minecraft.resources.Identifier;

public class CustomCrosshairMod implements ClientModInitializer {
    /** Mira vanilla (usada quando a mira custom esta desativada). */
    private static HudElement vanilla;

    /** Elemento unico e reutilizado: zero alocacao por frame. */
    private static final HudElement CROSSHAIR = (graphics, deltaTracker) -> {
        if (!CrosshairRenderer.render(graphics) && vanilla != null) {
            vanilla.extractRenderState(graphics, deltaTracker);
        }
    };

    @Override
    public void onInitializeClient() {
        CrosshairConfig.load();

        KeyMapping.Category category = KeyMapping.Category.register(
                Identifier.fromNamespaceAndPath("customcrosshair", "main"));

        KeyMapping menuKey = KeyMappingHelper.registerKeyMapping(new KeyMapping(
                "key.customcrosshair.menu",
                InputConstants.Type.KEYSYM,
                InputConstants.KEY_J, // tecla J
                category));

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            while (menuKey.consumeClick()) {
                if (mc.gui.screen() == null) mc.gui.setScreen(new CrosshairMenuScreen());
            }
        });

        HudElementRegistry.replaceElement(VanillaHudElements.CROSSHAIR, original -> {
            vanilla = original;
            return CROSSHAIR;
        });
    }
}
