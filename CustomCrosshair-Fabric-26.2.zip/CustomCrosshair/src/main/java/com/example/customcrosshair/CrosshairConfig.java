package com.example.customcrosshair;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;

public class CrosshairConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path PATH = FabricLoader.getInstance().getConfigDir().resolve("customcrosshair.json");
    private static CrosshairConfig instance = new CrosshairConfig();

    public boolean enabled = true;
    public boolean outline = true;

    // Mira (padrao = circulo verde com ponto central, igual a imagem 1)
    public int style = 2;       // 0 cruz, 1 ponto, 2 circulo, 3 T
    public int size = 5;        // 1..30
    public int thickness = 1;   // 1..8
    public int gap = 3;         // 0..15 (cruz/T)
    public int dotSize = 1;     // 0..6 ponto central (0 = desligado)
    public int red = 0, green = 255, blue = 0;
    public int alpha = 255;     // 20..255

    // Quando a mira esta sobre uma entidade
    public int targetMode = 3;  // 0 nenhum, 1 mudar cor, 2 cantos, 3 cor + cantos
    public int targetRed = 255, targetGreen = 0, targetBlue = 0;
    public int cornerSize = 4;  // 1..15 comprimento do braco do canto
    public int cornerDist = 9;  // 3..30 distancia do centro

    public transient boolean dirty = true;

    public static CrosshairConfig get() { return instance; }

    public int argb() { return (alpha << 24) | (red << 16) | (green << 8) | blue; }
    public int targetArgb() { return (alpha << 24) | (targetRed << 16) | (targetGreen << 8) | targetBlue; }

    public static void load() {
        try {
            if (Files.exists(PATH)) {
                CrosshairConfig c = GSON.fromJson(Files.readString(PATH), CrosshairConfig.class);
                if (c != null) instance = c;
            }
        } catch (Exception ignored) { }
        instance.clamp();
        instance.dirty = true;
    }

    public static void save() {
        try { Files.writeString(PATH, GSON.toJson(instance)); } catch (Exception ignored) { }
    }

    public void reset() {
        CrosshairConfig d = new CrosshairConfig();
        enabled = d.enabled; outline = d.outline; style = d.style; size = d.size;
        thickness = d.thickness; gap = d.gap; dotSize = d.dotSize;
        red = d.red; green = d.green; blue = d.blue; alpha = d.alpha;
        targetMode = d.targetMode; targetRed = d.targetRed; targetGreen = d.targetGreen; targetBlue = d.targetBlue;
        cornerSize = d.cornerSize; cornerDist = d.cornerDist;
        dirty = true;
    }

    private static int cl(int v, int lo, int hi) { return Math.max(lo, Math.min(hi, v)); }

    private void clamp() {
        style = cl(style, 0, 3); size = cl(size, 1, 30); thickness = cl(thickness, 1, 8);
        gap = cl(gap, 0, 15); dotSize = cl(dotSize, 0, 6);
        red = cl(red, 0, 255); green = cl(green, 0, 255); blue = cl(blue, 0, 255); alpha = cl(alpha, 20, 255);
        targetMode = cl(targetMode, 0, 3);
        targetRed = cl(targetRed, 0, 255); targetGreen = cl(targetGreen, 0, 255); targetBlue = cl(targetBlue, 0, 255);
        cornerSize = cl(cornerSize, 1, 15); cornerDist = cl(cornerDist, 3, 30);
    }
}
