package com.example.customcrosshair;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.world.phys.HitResult;

import java.util.ArrayList;
import java.util.List;

/**
 * Otimizado: formas calculadas uma vez (quando a config muda) e guardadas em int[].
 * Por frame: so fill(), sem alocacao, sem texturas. A checagem de alvo e um
 * simples getType() no crosshairTarget que o jogo ja calcula.
 */
public final class CrosshairRenderer {
    private static int[] base = new int[0];     // mira principal
    private static int[] corners = new int[0];  // cantos "L"
    private static int color, targetColor, outlineColor;

    private CrosshairRenderer() { }

    public static boolean render(GuiGraphicsExtractor g) {
        CrosshairConfig c = CrosshairConfig.get();
        if (!c.enabled) return false;
        Minecraft mc = Minecraft.getInstance();
        if (!mc.options.getCameraType().isFirstPerson()) return false;
        HitResult hit = mc.hitResult;
        boolean onEntity = hit != null && hit.getType() == HitResult.Type.ENTITY;
        draw(g, mc.getWindow().getGuiScaledWidth() / 2, mc.getWindow().getGuiScaledHeight() / 2, onEntity);
        return true;
    }

    public static void draw(GuiGraphicsExtractor ctx, int cx, int cy, boolean targeting) {
        CrosshairConfig c = CrosshairConfig.get();
        if (c.dirty) { rebuild(c); c.dirty = false; }

        boolean recolor = targeting && (c.targetMode == 1 || c.targetMode == 3);
        boolean showCorners = targeting && (c.targetMode == 2 || c.targetMode == 3);

        paint(ctx, cx, cy, base, recolor ? targetColor : color, c.outline);
        if (showCorners) paint(ctx, cx, cy, corners, targetColor, c.outline);
    }

    private static void paint(GuiGraphicsExtractor ctx, int cx, int cy, int[] r, int col, boolean outline) {
        if (outline) {
            for (int i = 0; i < r.length; i += 4)
                ctx.fill(cx + r[i] - 1, cy + r[i + 1] - 1, cx + r[i + 2] + 1, cy + r[i + 3] + 1, outlineColor);
        }
        for (int i = 0; i < r.length; i += 4)
            ctx.fill(cx + r[i], cy + r[i + 1], cx + r[i + 2], cy + r[i + 3], col);
    }

    private static void rebuild(CrosshairConfig c) {
        color = c.argb();
        targetColor = c.targetArgb();
        outlineColor = c.alpha << 24;

        final int s = c.size, t = c.thickness, g = c.gap, h = t / 2;
        List<Integer> b = new ArrayList<>();
        switch (c.style) {
            case 1 -> { int a = s / 2; add(b, -a, -a, -a + s, -a + s); }
            case 2 -> ring(b, s, Math.min(t, s));
            case 3 -> {
                add(b, -(g + s), -h, -g, -h + t);
                add(b, g, -h, g + s, -h + t);
                add(b, -h, g, -h + t, g + s);
            }
            default -> {
                add(b, -h, -(g + s), -h + t, -g);
                add(b, -h, g, -h + t, g + s);
                add(b, -(g + s), -h, -g, -h + t);
                add(b, g, -h, g + s, -h + t);
            }
        }
        if (c.style != 1 && c.dotSize > 0) {
            int a = c.dotSize / 2;
            add(b, -a, -a, -a + c.dotSize, -a + c.dotSize);
        }
        base = toArray(b);

        // Cantos "L" (estilo da imagem 2), sem sobreposicao entre os dois braços
        List<Integer> k = new ArrayList<>();
        int d = c.cornerDist, len = Math.min(c.cornerSize, d), tt = Math.min(t, len);
        for (int sx = -1; sx <= 1; sx += 2) {
            for (int sy = -1; sy <= 1; sy += 2) {
                int ox = sx > 0 ? d + 1 : -d;   // borda externa X
                int oy = sy > 0 ? d + 1 : -d;   // borda externa Y
                addNorm(k, ox, oy, ox - sx * len, oy - sy * tt);          // braco horizontal
                if (len > tt) addNorm(k, ox, oy - sy * tt, ox - sx * tt, oy - sy * len); // braco vertical
            }
        }
        corners = toArray(k);
    }

    /** Anel por scanlines: no maximo 2 retangulos por linha. */
    private static void ring(List<Integer> out, int r, int thick) {
        int ri = r - thick;
        for (int dy = -r; dy <= r; dy++) {
            int outer = (int) Math.sqrt(r * r + r - dy * dy);
            if (ri > 0 && Math.abs(dy) < ri) {
                int inner = (int) Math.sqrt(ri * ri + ri - dy * dy);
                add(out, -outer, dy, -inner, dy + 1);
                add(out, inner + 1, dy, outer + 1, dy + 1);
            } else {
                add(out, -outer, dy, outer + 1, dy + 1);
            }
        }
    }

    private static void add(List<Integer> l, int x1, int y1, int x2, int y2) {
        if (x2 > x1 && y2 > y1) { l.add(x1); l.add(y1); l.add(x2); l.add(y2); }
    }

    private static void addNorm(List<Integer> l, int x1, int y1, int x2, int y2) {
        add(l, Math.min(x1, x2), Math.min(y1, y2), Math.max(x1, x2), Math.max(y1, y2));
    }

    private static int[] toArray(List<Integer> l) {
        int[] a = new int[l.size()];
        for (int i = 0; i < a.length; i++) a[i] = l.get(i);
        return a;
    }
}
