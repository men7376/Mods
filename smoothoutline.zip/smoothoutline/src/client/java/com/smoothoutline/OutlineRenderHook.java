package com.smoothoutline;

/**
 * THE ONLY FILE THAT TOUCHES THE 26.2 RENDER API.
 *
 * The block-outline rendering was reworked in 26.x (extract/submit phases), and I could not
 * compile against 26.2 here. Hook it using Fabric API's block outline event
 * (LevelRenderEvents / WorldRenderEvents.BLOCK_OUTLINE in your Fabric API version):
 *
 *   1. In the event, take the targeted block's outline shape -> AABB `target` (world coords).
 *   2. AABB box = OutlineAnimator.step(target);
 *   3. Draw the 12 edges of `box` (minus camera position) with the LINES render type,
 *      color = OutlineAnimator.color(), width = OutlineConfig.INSTANCE.lineWidth.
 *   4. Return false / cancel so vanilla's black outline doesn't draw (if enabled).
 *   5. When no block is targeted: OutlineAnimator.reset().
 *
 * Send me the compile errors and I will fill this in exactly.
 */
public final class OutlineRenderHook {
    public static void register() {
        // TODO: register the 26.2 block outline event here (see comment above).
    }
}
