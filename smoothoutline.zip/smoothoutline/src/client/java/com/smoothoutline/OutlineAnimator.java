package com.smoothoutline;

import net.minecraft.world.phys.AABB;

/** Pure logic (no Minecraft rendering API): smooth box tracking + color. */
public final class OutlineAnimator {
    private static double[] cur;           // minX,minY,minZ,maxX,maxY,maxZ
    private static long lastNanos = System.nanoTime();

    /** Returns the box to draw this frame (world coords), eased toward target. */
    public static AABB step(AABB target) {
        OutlineConfig c = OutlineConfig.INSTANCE;
        long now = System.nanoTime();
        double dt = Math.min((now - lastNanos) / 1.0e9, 0.1);
        lastNanos = now;

        double[] t = { target.minX, target.minY, target.minZ, target.maxX, target.maxY, target.maxZ };
        if (cur == null || !c.smooth) { cur = t; return target; }

        double dx = t[0] - cur[0], dy = t[1] - cur[1], dz = t[2] - cur[2];
        if (dx * dx + dy * dy + dz * dz > c.snapDistance * c.snapDistance) { cur = t; return target; }

        double k = 1.0 - Math.exp(-c.smoothSpeed * dt);
        for (int i = 0; i < 6; i++) cur[i] += (t[i] - cur[i]) * k;
        return new AABB(cur[0], cur[1], cur[2], cur[3], cur[4], cur[5]);
    }

    public static void reset() { cur = null; }

    /** ARGB color for the current frame. */
    public static int color() {
        OutlineConfig c = OutlineConfig.INSTANCE;
        int a = Math.round(Math.max(0, Math.min(1, c.alpha)) * 255) << 24;
        double phase = (System.nanoTime() / 1.0e9) * c.gradientSpeed;
        int rgb;
        switch (c.mode) {
            case RAINBOW -> rgb = java.awt.Color.HSBtoRGB((float) (phase % 1.0), 0.85f, 1f);
            case GRADIENT -> {
                int x = OutlineConfig.parse(c.color, 0xFFFF8800), y = OutlineConfig.parse(c.colorB, 0xFF0088FF);
                float f = (float) (0.5 - 0.5 * Math.cos(phase * 2 * Math.PI));
                int r = (int) (((x >> 16) & 255) * (1 - f) + ((y >> 16) & 255) * f);
                int g = (int) (((x >> 8) & 255) * (1 - f) + ((y >> 8) & 255) * f);
                int b = (int) ((x & 255) * (1 - f) + (y & 255) * f);
                rgb = (r << 16) | (g << 8) | b;
            }
            default -> rgb = OutlineConfig.parse(c.color, 0xFFFF8800);
        }
        return a | (rgb & 0xFFFFFF);
    }
}
