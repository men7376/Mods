package com.smoothoutline;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;

/** Config file: .minecraft/config/smoothoutline.json (edit it, then use /smoothoutline reload). */
public class OutlineConfig {
    public enum Mode { SOLID, GRADIENT, RAINBOW }

    public boolean enabled = true;
    public Mode mode = Mode.SOLID;
    public String color = "#FF8800";       // solid color (orange)
    public String colorB = "#0088FF";      // second color for GRADIENT (blue)
    public float gradientSpeed = 0.5f;     // cycles per second (GRADIENT / RAINBOW)
    public float alpha = 1.0f;             // 0..1
    public float lineWidth = 2.5f;
    public boolean smooth = true;
    public float smoothSpeed = 18f;        // higher = faster slide (try 8 slow, 30 snappy)
    public float snapDistance = 6f;        // farther than this (blocks) = jump instead of slide

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("smoothoutline.json");
    public static OutlineConfig INSTANCE = new OutlineConfig();

    public static void load() {
        try {
            if (Files.exists(FILE)) {
                OutlineConfig c = GSON.fromJson(Files.readString(FILE), OutlineConfig.class);
                if (c != null) INSTANCE = c;
            }
            Files.writeString(FILE, GSON.toJson(INSTANCE));
        } catch (Exception e) {
            System.err.println("[SmoothOutline] config error: " + e);
        }
    }

    public static int parse(String hex, int fallback) {
        try { return 0xFF000000 | Integer.parseInt(hex.replace("#", ""), 16); }
        catch (Exception e) { return fallback; }
    }
}
