package com.smoothoutline;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommands;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;

public class SmoothOutlineClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        OutlineConfig.load();
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
            dispatcher.register(ClientCommands.literal("smoothoutline")
                .then(ClientCommands.literal("reload").executes(ctx -> {
                    OutlineConfig.load();
                    OutlineAnimator.reset();
                    return 1;
                }))));
        OutlineRenderHook.register();
    }
}
